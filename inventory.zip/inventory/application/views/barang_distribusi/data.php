<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
    <div class="card-header bg-white py-3">
        <div class="row">
            <div class="col">
                <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                    Stok Barang
                </h4>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped w-100 dt-responsive nowrap" id="dataTable">
            <thead>
                <tr>
                    <th>No. </th>
                    <th>Tanggal Keluar</th>
                    <th>Nama Barang</th>
                    <th>Stok Gudang</th>
                    <th>Jumlah Masuk</th>
                    <th>Jumlah Keluar</th>
                    <th>Sisa Stok</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                if ($barangdistribusi) :
                    foreach ($barangdistribusi as $bd) :
                        ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $bd['tanggal_keluar']; ?></td>
                    <td><?= $bd['nama_barang']; ?></td>
                    <td><?= $bd['stok_gudang']; ?></td>
                    <td><?= $bd['jumlah_masuk'] . ' ' . $bd['nama_satuan']; ?></td>
                    <td><?= $bd['jumlah_keluar'] . ' ' . $bd['nama_satuan']; ?></td>
                    <td><?= $bd['stok']; ?></td>
                </tr>
                <?php endforeach; ?>
                <?php else : ?>
                <tr>
                    <td colspan="7" class="text-center">
                        Data Kosong
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
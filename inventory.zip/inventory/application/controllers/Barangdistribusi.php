<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Barangdistribusi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Sisa Stok Barang";
        $data['barangdistribusi'] = $this->admin->getBarangDistribusi();
        $this->template->load('templates/dashboard', 'barang_distribusi/data', $data);
    }

    private function _validasi()
    {       
        $input = $this->input->post('barang_id', true);
        $stok_gudang = $this->admin->get('barang', ['id_barang' => $input])['stok_gudang'];
        $stok = $this->admin->get('barang', ['id_barang' => $input])['stok'];
        $stok_valid = $stok_gudang + $stok + 1;

        $this->form_validation->set_rules(
            'jumlah_distribusi',
            'Jumlah distribusi',
            "required|trim|numeric|greater_than[0]|less_than[{$stok_valid}]",
            [
                'less_than' => "Jumlah distribusi tidak boleh lebih dari {$stok}"
            ]
        );
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Sisa Stok Barang";
            $data['barang'] = $this->admin->get('barang', null, ['stok >' => 0]);

            // Mendapatkan dan men-generate kode transaksi barang distribusi
            $kode = 'T-BK-' . date('ymd');
            $kode_terakhir = $this->admin->getMax('barang_distribusi', 'id_barang_distribusi', $kode);
            $kode_tambah = substr($kode_terakhir, -5, 5);
            $kode_tambah++;
            $number = str_pad($kode_tambah, 5, '0', STR_PAD_LEFT);
            $data['id_barang_distribusi'] = $kode . $number;

            $this->template->load('templates/dashboard', 'barang_distribusi/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('barang_distribusi', $input);

            if ($insert) {
                set_pesan('data berhasil disimpan.');
                redirect('barangdistribusi');
            } else {
                set_pesan('Opps ada kesalahan!');
                redirect('barangdistribusi/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('barang_distribusi', 'id_barang_distribusi', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('barangdistribusi');
    }
}